# escolas-movimentos-literarios
Site sobre os principais movimentos literários entre o século 12 a 18
INTEGRANTES:
Maria Paula Ferreira 
Thales Viana
Tiago Moreira
